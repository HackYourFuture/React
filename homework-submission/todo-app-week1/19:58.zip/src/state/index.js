export const ITEMS = [
    { name: "Todo item 1", color: "", checked: false, edit: false, id: 1 },
    { name: "Todo item 2", color: "pink", checked: false, edit: false, id: 2 },
    { name: "Todo item 3", color: "purple", checked: false, edit: false, id: 3 }
];
export const COLORS = [
    { name: "red", checked: !0, id: 1 },
    { name: "pink", checked: !1, id: 2 },
    { name: "purple", checked: !1, id: 3 },
    { name: "blue", checked: !1, id: 4 },
    { name: "green", checked: !1, id: 5 },
    { name: "yellow", checked: !1, id: 6 }
];